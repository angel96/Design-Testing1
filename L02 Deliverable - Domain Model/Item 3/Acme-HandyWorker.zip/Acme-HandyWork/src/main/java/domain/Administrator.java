
package domain;

import javax.persistence.Entity;

@Entity
public class Administrator extends Actor {
}
