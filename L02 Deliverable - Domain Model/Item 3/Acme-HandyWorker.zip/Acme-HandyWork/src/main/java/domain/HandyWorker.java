
package domain;

import javax.persistence.Entity;

@Entity
public class HandyWorker extends Endorsable {

}
