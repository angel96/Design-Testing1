package domain;


public class PatternsMain {

}
