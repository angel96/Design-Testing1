
package domain;

import javax.persistence.Entity;

@Entity
public class PersonalRecord extends Actor {

}
