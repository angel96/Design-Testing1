SET old_passwords = 0;
SELECT PASSWORD('V3ry-$tr0ng-P@$$W0RD');